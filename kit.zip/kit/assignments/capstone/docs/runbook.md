# Runbook - Meridian Support Assistant

## 1. What this system does

The assistant runs locally against the synthetic Meridian corpus and harness backends. It answers supported status, fee, escalation, and policy questions and cites policy document identifiers. It does not execute transfers or replace human approval. Any outage or uncertain action should be treated as a hand-off, not a successful completion.

## 2. Start, stop, and health check

From the kit root, activate the virtual environment and install the pinned-range requirements. Run `python app.py --demo` from `assignments\capstone`. A healthy local run exits with code zero and prints the scripted questions and answers. Run `python -m autograde.run --capstone --root . -v` from the kit root for the component, integration, safety, outage, and zero-cost checks. To stop the demo, wait for its short script to exit; it does not start a server or background worker.

For an outage check in PowerShell, set `$env:GAMEDAY_FAULT="tool_outage"`, run the demo, and then clear it with `Remove-Item Env:GAMEDAY_FAULT`. The output should explicitly say `degraded`; audit entries should verify, and traces should contain closed spans. Files are local JSONL under `assignments\capstone\audit` and `assignments\capstone\traces`.

To exercise all four synthetic game-day faults and save request-level measurements, run `python assignments\capstone\gameday\run_probe.py` from the kit root. It writes a timestamped JSON result and separate audit/trace JSONL files per fault. The probe uses synthetic requests only; its latency and token measurements are not production service-level data.

## 3. Signals to inspect

Review trace span names and durations, the degraded response rate, tool errors, and audit-chain verification. `a6_evals.analyze_trace` reports root duration, slowest non-root span, duplicate calls, token totals, and span count. Evaluation reports include document precision/recall, lexical faithfulness, hashing-vector answer relevance, p50/p95 latency, token totals, and simulated cost. These are deterministic training metrics, not production service-level indicators.

## 4. Troubleshooting

| Symptom | Likely cause | How to confirm | Action |
|---|---|---|---|
| `ModuleNotFoundError: harness` | Wrong working directory or removed path setup | Run the demo from `assignments\capstone`; inspect app path bootstrap | Restore the expected kit/capstone paths |
| Current fee is wrong or stale | Stale document ranked or incorrect status metadata | Inspect retrieved `doc_id` and the corpus front matter | Ensure superseded filtering is enabled and rerun RAG checks |
| Policy answer contains an instruction from a passage | Sanitization failed or an untrusted sentence escaped | Inspect the retrieval span, blocked source, and guard findings | Disable policy answering, hand off, and add a generalizable detection test |
| Account request returns degraded | Tool outage or injected fault | Check the response and trace error; inspect `GAMEDAY_FAULT` | Clear the fault only after the dependency is available; retry a read-only request |
| Audit verification fails | Entry edit, deletion, malformed JSON, or chain break | Run `AuditLog(path).verify()` and note `first_bad` | Preserve the file for investigation; append operations are refused until the issue is investigated; do not rewrite the chain in place |

## 5. Escalation

Suspected fraud must be sent to Compliance within 24 hours. P1 suspected fraud has a 15-minute first-response target; delayed money movement is P2 with a two-hour first response; general requests are P3 with a one-business-day first response. The prototype does not page these teams. The operator must use the approved bank process and include the ticket identifier and relevant source documents.

## 6. Rollback and safe mode

The safest rollback is to stop using the assistant and return to the existing human process. Do not disable authorization, redaction, audit, or injection filtering to restore convenience. Under outage conditions, route requests to a person and preserve the audit/trace files. Any release that changes fees, roles, or payment policy must be tested against the synthetic corpus and reviewed before deployment.

## 7. Known issues

The harness uses synthetic accounts and a rule-based offline model. The retriever's hashing embedding is lexical, not semantic. Regex-based PII recognition and injection detection cannot guarantee detection of every unseen form. The audit log has no production key management, retention scheduler, access-control integration, or remote backup. The prototype is not approved for real customer data, financial advice, or payment execution.
