# Business case: Case C wire exception handling

**Stakeholder:** Ingrid Solberg, Head of Payments. **Process today:** six operators review about 150 exceptions each day. Exceptions include incorrect beneficiary details, missed cut-offs, screening matches, and requests above an operator's authority. The process is time pressured near the domestic 4 PM and international 1 PM cut-offs.

## What the assistant does, and what stays human

This prototype can retrieve written policy, quote current fees, check synthetic account status, and create a support escalation ticket. It does not decide whether to release, return, or amend a wire, and it cannot post a transfer. The stakeholder's wish to automate every exception is constrained by payment policy: wires of $10,000 or more require two different approvers, an initiator cannot approve their own wire, and new beneficiaries require human approval. The interview's claimed repeat-customer waiver for dual control is not in the written policy. Until the policy owner resolves that conflict in writing, the assistant treats the published policy as authoritative and routes uncertain payment decisions to a person.

## Contradictions and gaps to resolve

The proposed dual-control waiver is an undocumented operational practice and conflicts with the formal rule. The Head of Payments and Compliance must decide whether a documented exception is permitted and update controlled policy before automation can enforce it. This prototype abstains from transaction execution, records the source documents used, and requires human review for transfers or exceptions.

## Metrics and assumptions

| Measure | Baseline | Pilot target | Assumption |
|---|---|---|---|
| Operator time per exception | Not measured; stakeholder says one minute saved would help | Measure time for 2 weeks; seek a 10% reduction in policy lookup time | Retrieval can reduce document searching, not judgment |
| Incorrect release / duplicate action | Not measured | Zero automated releases; no duplicate escalation tickets | The prototype does not execute payment actions |
| Exception volume | Interview estimate: about 150/day | Measure actual eligible policy lookups | Interview estimate may vary by season |

## ROI as a range

At 150 cases per day, assuming 220 working days, one minute saved per case would equal 550 operator hours annually (150 x 220 / 60). A conservative pilot assumes only 10% of cases benefit, or 55 hours; an optimistic estimate assumes all cases benefit, or 550 hours. These are theoretical capacity ranges before implementation, review, exception handling, and operational overhead. No monetary return is claimed because loaded labor cost and eligible-case share have not been measured.

## Weakest claim and pilot

The weakest assumption is that a policy assistant shortens exception handling without creating extra verification work. Run a two-week, read-only pilot with two operators using synthetic or approved test cases. Compare measured search time and source correctness against the current process. Stop if any answer cites a superseded source, if a policy contradiction is presented as settled, or if an operator reports pressure to bypass dual control.
