# Decision log

## Framework

The implementation uses a small hand-rolled orchestration loop with the supplied `RuleLLM` and typed harness tools. This keeps the capstone offline, deterministic, and easy to inspect; the task is to demonstrate authorization, retrieval, validation, and hand-off rather than framework integration.
Per-request authorization is applied by the agent using the caller's actual role and selected action, rather than guessing a tool at the outer request boundary. This avoids denying an analyst's read-only policy question simply because the question mentions a fee.

## Retrieval

Section chunking is the default because each policy file is short and its headings correspond to useful answer units. BM25 and hashing-embedding rankings are fused with reciprocal rank fusion. The public and hold-out grader reported recall@5 of 0.77 for BM25, 0.93 for dense hashing, and 0.75 for hybrid. The hashing embedder is a local lexical baseline, not a semantic model. Superseded fee material is excluded from ordinary retrieval.

## Safety and operations

Retrieved content is sanitized before it reaches the rule-based model. Tools validate inputs and return narrow structures; ticket creation is idempotent. The integrated application does not execute transfers. Local JSONL traces and chained audit entries are chosen for transparent testing, not as a production retention system.
The audit writer verifies the current chain before appending and refuses to continue after a malformed or tampered entry. Fee quantities are parsed separately from amounts, and a domestic-wire quote may use the account's product only through the PII-limited status tool.

## Assistant use

An AI assistant using Copilot SDK in VS Code helped implement and test the starter-kit code and draft these project documents. The learner should review every implementation detail and be able to explain it during the defence.
