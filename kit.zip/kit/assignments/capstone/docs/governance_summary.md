# Governance and security summary

This is a local educational prototype, not an approved banking system. All included records are synthetic. The design follows least privilege, source attribution, data minimization, human hand-off, and explicit degraded status. There is no payment-posting tool in the application path.

| Control | Evidence | Status | Mitigation or next step |
|---|---|---|---|
| Least-privilege tools | `a7_guard.authorize`; integration checks for analyst and support roles | Met for the defined role/tool matrix | Revalidate roles against bank identity and access-management policy before production |
| Human approval | SEC-001, PAY-001, and the wire-exception business case | Partial: no transfer execution; hand-off is explicit | Add a separately approved workflow only after authority limits and approvals are tested |
| PII minimization and masking | Safe account-status model, `redact_pii`, audit argument redaction | Met for covered patterns and synthetic tests | Test bank-specific formats and perform privacy review before processing real data |
| Prompt-injection defenses | Sentence detector/sanitizer and secure-answer integration test for FAQ-001 | Partial: pattern-based, not a formal guarantee | Add unseen attack tests, review false positives, and keep retrieved content data-only |
| Tamper-evident audit | `AuditLog.verify()` and integration audit test | Met for local append/hash-chain behavior | Protect file permissions, define retention/access, and archive to controlled storage in production |
| Source attribution | Policy tool returns source IDs; answer prompt requests citations | Met for tested policy questions | Monitor source correctness and reject unsupported answers |
| Seven-year retention | SEC-001 and KYC-001 corpus content | Gap: local prototype has no retention scheduler | Implement retention controls in approved storage; never infer compliance from local files |
| Monitoring and drift | Trace JSONL and deterministic evaluation reports | Partial: no alerting or production dashboard | Define owners, thresholds, and periodic test refresh before pilot |

Potential model output is treated as untrusted. An outage response must not resemble a successful lookup. Uncertain payment decisions, complaints, and fraud cases require the existing human process. Evaluation results are evidence about the synthetic dataset only and do not certify safety, legal compliance, or production readiness.
