# Meridian Support Assistant architecture

## Context

This is a local training prototype for Meridian Bank support staff. A request can ask for account status, a fee quote, escalation, or policy guidance. The data is synthetic and held in the learner kit. Runtime dependencies are Python packages installed locally; the application does not call a hosted model, vector database, or banking system.

## Diagram

```mermaid
flowchart TD
  U[Support user and role] --> A[Authorize request]
  A -->|denied| H[Human hand-off]
  A --> R[Intent routing]
  R --> T[Validated account, fee, or ticket tool]
  R --> Q[Policy retrieval]
  Q --> C[Injection sentence sanitization]
  C --> M[Offline RuleLLM answer]
  T --> P[PII redaction]
  M --> P
  P --> O[AgentResult with sources]
  A --> X[Trace spans]
  T --> X
  Q --> X
  O --> L[Hash-chained audit entry]
```

## Components and data flow

`app.py` is the integration boundary. It wraps each request in tracing, resilience, and audit handling, then calls `a4_agent.handle`. The agent enforces authorization for each selected action using the actual caller role and uses `a4_tools` for structured, validated lookups, quotes, and idempotent tickets. Policy requests call `search_policy` and the guard's secure answer path. `a2_rag` parses Markdown front matter and keeps `doc_id`, `chunk_id`, and document status on each chunk. BM25 and a deterministic local hashing embedder provide a hybrid ranked list. The normal index excludes superseded documents; an explicit diagnostic query may include them.

Retrieved passages are data, not instructions. `a7_guard` detects instruction-like sentences, removes them before the LLM sees the context, and records affected document identifiers. The answer is redacted before returning. Account records can contain names, phones, emails, and full numbers, but the status tool emits only an account identifier, product, status, masked number, and optional freeze reason.

## Rejected alternatives

- **Hosted model and hosted vector database:** rejected because they add credentials, recurring cost, network/privacy exposure, and nondeterministic behavior that conflicts with the offline zero-cost requirement. The local rule model and hashing embedder are limited but reproducible.
- **Direct payment execution or automatic exception approval:** rejected because written policy requires human authority and dual control. The assistant may retrieve the relevant rule and hand the case to a person, but it has no payment-posting tool.
- **A single dense retrieval strategy:** rejected because exact identifiers, fee amounts, and branch names matter in this small policy corpus. Hybrid retrieval is retained and evaluated against a lexical baseline.

## Decisions, measurements, and failure modes

Section chunks were chosen as the default because headings delimit compact policy topics and preserve their context. The visible autograder reported recall@5 of 0.77 for BM25, 0.93 for dense hashing, and 0.75 for hybrid retrieval. Those measurements include the grader's hidden test set and are not a guarantee of production relevance. Hybrid ranking remains the default to combine exact lexical matches and overlapping hashed features, while recall and source citations are checked separately.

The circuit breaker and retry helper are standalone primitives with injected clocks and sleep functions for deterministic tests. The integrated app handles a tool outage by returning a degraded, human-handoff result; it does not claim a successful lookup. Traces expose request stages, and audit entries chain canonical JSON hashes. Logs currently have no retention scheduler, access-control service, or durable external archival; production deployment would need those controls, monitoring, and a security review.
