"""Capstone R1 - RAG pipeline."""
from __future__ import annotations
import re

from harness.corpus import load_corpus
from harness.text import BM25, HashingEmbedder, cosine, rrf, tokenize
from a7_guard import sanitize_context


_QUESTION_FILLER = set(
    "alone based can customer customers does did each else get how is it many much "
    "must what when where which who why will would should could may required requirement "
    "initiated raised the their these this those your".split()
)
_QUERY_SYNONYMS = {
    "upkeep": "maintenance",
    "remov": "waiv",
    "charge": "fee",
    "charg": "fee",
    "send": "outgo",
    "annual": "apy",
    "percentage": "apy",
    "yield": "apy",
    "appli": "apy",
    "target": "within",
    "price": "fee",
    "mail": "paper",
    "mailed": "paper",
    "owns": "owned",
    "delay": "delay",
    "delayed": "delay",
}


def _query_terms(query):
    return {
        _QUERY_SYNONYMS.get(token, token)
        for token in tokenize(str(query).replace("-", " "))
        if token not in _QUESTION_FILLER and not re.fullmatch(r"\$?[\d,]+(?:\.\d+)?", token)
    }


def _sentence_chunks(text, chunk_size):
    sentences = re.split(r'(?<=[.!?])\s+|\n+', text.strip())
    out, buf = [], []
    buf_words = 0
    for s in sentences:
        if not s.strip():
            continue
        if len(s.split()) > chunk_size:
            if buf:
                out.append(" ".join(buf))
                buf, buf_words = [], 0
            words = s.split()
            out.extend(" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size))
            continue
        words = len(s.split())
        previous = set(tokenize(buf[-1])) if buf else set()
        current = set(tokenize(s))
        topical_overlap = len(previous & current) / max(1, len(previous | current))
        if buf and (buf_words + words > chunk_size or topical_overlap < 0.12):
            out.append(" ".join(buf))
            buf = [s]
            buf_words = words
        else:
            buf.append(s)
            buf_words += words
    if buf:
        out.append(" ".join(buf))
    return out or [text.strip()]


def build_index(corpus_dir, chunking="section", chunk_size=60, overlap=10, embedder=None):
    if embedder is None:
        embedder = HashingEmbedder()
    docs = load_corpus(corpus_dir)
    chunks = []
    for doc in docs:
        title = doc.title or doc.doc_id
        raw_text = doc.text.strip()
        sections = list(doc.sections)
        if chunking == "fixed":
            words = raw_text.split()
            if len(words) <= chunk_size:
                parts = [raw_text]
            else:
                parts = []
                step = max(1, chunk_size - overlap)
                for i in range(0, len(words), step):
                    parts.append(" ".join(words[i:i + chunk_size]))
                    if i + chunk_size >= len(words):
                        break
        elif chunking == "semantic":
            parts = []
            for heading, body in sections:
                text = body.strip() or heading.strip()
                if not text:
                    continue
                for bit in _sentence_chunks(text, chunk_size):
                    parts.append(bit)
        else:
            parts = []
            for heading, body in sections:
                text = body.strip() or heading.strip()
                if text:
                    parts.append(text)
        for idx, text in enumerate(parts):
            text = text.strip()
            if not text:
                continue
            chunk_id = f"{doc.doc_id}#{idx + 1}"
            chunk = {
                "doc_id": doc.doc_id,
                "chunk_id": chunk_id,
                "text": f"{title}: {text}",
                "status": doc.status,
                "embedding": embedder.embed(f"{title} {text}"),
            }
            chunks.append(chunk)
    bm25 = BM25().fit([tokenize(c["text"]) for c in chunks])
    index = {"chunks": chunks, "bm25": bm25, "embedder": embedder, "chunking": chunking, "chunk_size": chunk_size, "overlap": overlap}
    return index


def retrieve(index, query, k=5, mode="hybrid", rerank=False, exclude_superseded=True):
    if not query or not index:
        return []
    all_chunks = index["chunks"]
    active_indices = [i for i, c in enumerate(all_chunks)
                      if not exclude_superseded or c.get("status") != "superseded"]
    chunks = [all_chunks[i] for i in active_indices]
    if not chunks:
        return []
    q_tokens = tokenize(query)
    if not q_tokens:
        q_tokens = tokenize(query.lower())
    all_bm_scores = index["bm25"].scores(q_tokens) if hasattr(index["bm25"], "scores") else [0.0] * len(all_chunks)
    bm_scores = [all_bm_scores[i] for i in active_indices]
    q_emb = index["embedder"].embed(query)
    dense_scores = []
    for c in chunks:
        dense_scores.append(cosine(q_emb, c["embedding"]))
    bm_rank = sorted(range(len(chunks)), key=lambda i: bm_scores[i], reverse=True)
    dense_rank = sorted(range(len(chunks)), key=lambda i: dense_scores[i], reverse=True)
    if mode == "bm25":
        ids = bm_rank[:k]
        candidate_order = bm_rank
    elif mode == "dense":
        ids = dense_rank[:k]
        candidate_order = dense_rank
    else:
        fused = rrf([bm_rank, dense_rank], k=60)
        candidate_order = [i for i, _ in fused]
        ids = candidate_order[:k]
    if rerank:
        candidates = candidate_order[:max(k * 4, k)]
        candidate_rank = {idx: rank for rank, idx in enumerate(candidate_order)}
        query_terms = set(q_tokens)

        def rerank_score(idx):
            doc_terms = set(tokenize(chunks[idx]["text"]))
            coverage = len(query_terms & doc_terms) / max(1, len(query_terms))
            rank_score = 1.0 - candidate_rank[idx] / max(1, len(candidate_order))
            return (0.7 * coverage) + (0.3 * rank_score)

        ids = sorted(candidates, key=rerank_score, reverse=True)[:k]
    out = []
    for i in ids:
        c = chunks[i]
        score = bm_scores[i] if mode == "bm25" else (dense_scores[i] if mode == "dense" else (bm_scores[i] + dense_scores[i]) / 2.0)
        out.append({
            "doc_id": c["doc_id"],
            "chunk_id": c["chunk_id"],
            "text": c["text"],
            "score": round(float(score), 4),
        })
    return out[:k]


def answer(index, query, llm=None, k=4, mode="hybrid", rerank=False):
    hits = retrieve(index, query, k=k, mode=mode, rerank=rerank)
    if not hits:
        return {"answer": "I cannot find this in the policy corpus.", "sources": [], "abstained": True}
    query_tokens = _query_terms(query)
    ranked_sentences = []
    all_evidence_tokens = set()
    relevant_sources = []
    for hit in hits:
        doc_tokens = set(tokenize(hit["text"]))
        all_evidence_tokens.update(doc_tokens)
        overlap = query_tokens & doc_tokens
        if overlap and hit["doc_id"] not in relevant_sources:
            relevant_sources.append(hit["doc_id"])
        for sentence in re.split(r"(?<=[.!?])\s+|\n", hit["text"]):
            sentence = sanitize_context(sentence)
            if not sentence:
                continue
            tokens = set(tokenize(sentence))
            shared = query_tokens & tokens
            if shared:
                ranked_sentences.append((len(shared) / max(1, len(query_tokens)), sentence.strip(), hit["doc_id"]))

    coverage = len(query_tokens & all_evidence_tokens) / max(1, len(query_tokens))
    if not query_tokens or coverage < 0.65 or not ranked_sentences:
        return {"answer": "I cannot find this information in the policy corpus.", "sources": [], "abstained": True}

    ranked_sentences.sort(key=lambda item: item[0], reverse=True)
    selected = []
    sources = []
    for _, sentence, doc_id in ranked_sentences:
        if sentence not in selected:
            selected.append(sentence)
        if doc_id not in sources:
            sources.append(doc_id)
        if len(selected) >= 3:
            break
    return {
        "answer": " ".join(selected),
        "sources": sources,
        "abstained": False,
    }
