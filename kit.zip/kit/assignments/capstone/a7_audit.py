"""Capstone R7 - tamper-evident audit log (append-only JSONL with a hash chain)."""
from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path

from a7_guard import redact_pii


class AuditLog:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def _redact_args(self, value):
        if isinstance(value, dict):
            return {k: self._redact_args(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._redact_args(v) for v in value]
        if isinstance(value, str):
            return redact_pii(value)
        return value

    def _hash_entry(self, entry):
        payload = json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def append(self, trace_id, user, tool, args, sources, outcome):
        verification = self.verify()
        if not verification["ok"]:
            raise ValueError(
                f"refusing to append to invalid audit chain at entry {verification['first_bad']}"
            )
        prev_hash = "0" * 64
        entries = self.entries()
        if entries:
            prev_hash = entries[-1]["hash"]
        seq = len(entries)
        redacted_args = self._redact_args(args or {})
        entry = {
            "seq": seq,
            "ts": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
            "trace_id": str(trace_id),
            "user": str(user),
            "tool": str(tool),
            "args": redacted_args,
            "sources": list(sources or []),
            "outcome": str(outcome),
            "prev_hash": prev_hash,
        }
        entry["hash"] = self._hash_entry({k: v for k, v in entry.items() if k != "hash"})
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
        return entry

    def entries(self):
        if not self.path.exists() or self.path.stat().st_size == 0:
            return []
        out = []
        for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.strip():
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
        return out

    def verify(self):
        if not self.path.exists() or self.path.stat().st_size == 0:
            return {"ok": True, "first_bad": None, "entries": 0}
        lines = [
            line for line in self.path.read_text(encoding="utf-8", errors="replace").splitlines()
            if line.strip()
        ]
        rows = []
        for idx, line in enumerate(lines):
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                return {"ok": False, "first_bad": idx, "entries": len(lines)}
            if not isinstance(row, dict):
                return {"ok": False, "first_bad": idx, "entries": len(lines)}
            rows.append(row)

        prev_hash = "0" * 64
        for idx, row in enumerate(rows):
            if row.get("seq") != idx:
                return {"ok": False, "first_bad": idx, "entries": len(lines)}
            if row.get("prev_hash") != prev_hash:
                return {"ok": False, "first_bad": idx, "entries": len(lines)}
            calc = {k: v for k, v in row.items() if k != "hash"}
            if self._hash_entry(calc) != row.get("hash"):
                return {"ok": False, "first_bad": idx, "entries": len(lines)}
            prev_hash = row.get("hash")
        return {"ok": True, "first_bad": None, "entries": len(lines)}
