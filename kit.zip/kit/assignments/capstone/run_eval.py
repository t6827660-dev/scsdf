"""Generate comparable baseline and reranked evaluation reports offline."""
from __future__ import annotations
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
KIT_ROOT = HERE.parents[1]
for path in (KIT_ROOT, HERE):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from a2_rag import answer, build_index, retrieve
from a6_evals import run_eval
from harness import CORPUS_DIR
from harness.text import count_tokens


def main():
    dataset = [
        json.loads(line)
        for line in (HERE / "eval_dataset.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    index = build_index(CORPUS_DIR, chunking="section")
    settings = (
        ("baseline", {"mode": "hybrid", "rerank": False}),
        ("after", {"mode": "hybrid", "rerank": True}),
    )
    comparison = {}
    for label, config in settings:
        def system_fn(question, config=config):
            hits = retrieve(index, question, k=5, **config)
            result = answer(index, question, k=5, **config)
            contexts = [hit["text"] for hit in hits]
            return {
                "answer": result["answer"],
                "contexts": contexts,
                "retrieved_ids": [hit["doc_id"] for hit in hits],
                "tool_calls": [],
                "tokens_in": count_tokens(question + " " + " ".join(contexts)),
                "tokens_out": count_tokens(result["answer"]),
                "abstained": result["abstained"],
            }

        report = run_eval(system_fn, dataset)
        report["retrieval_top1_accuracy"] = _top1_accuracy(index, dataset, config)
        comparison[label] = report

    reports_dir = HERE / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    for label, report in comparison.items():
        (reports_dir / f"eval_{label}.json").write_text(
            json.dumps(report, indent=2) + "\n",
            encoding="utf-8",
        )
    summary = {
        label: {
            "context_precision": report["metrics"].get("context_precision", 0.0),
            "context_recall": report["metrics"].get("context_recall", 0.0),
            "retrieval_top1_accuracy": report["retrieval_top1_accuracy"],
            "faithfulness": report["metrics"].get("faithfulness", 0.0),
            "answer_relevance": report["metrics"].get("answer_relevance", 0.0),
            "abstention_accuracy": report["metrics"].get("abstention_accuracy", 0.0),
            "latency_p95_ms": report["latency_ms"]["p95"],
            "sim_cost_usd": report["sim_cost_usd"],
        }
        for label, report in comparison.items()
    }
    (reports_dir / "retrieval_comparison.json").write_text(
        json.dumps(summary, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))


def _top1_accuracy(index, dataset, config):
    eligible = [row for row in dataset if row["gold_docs"]]
    if not eligible:
        return 0.0
    correct = 0
    for row in eligible:
        hits = retrieve(index, row["question"], k=1, **config)
        correct += bool(hits and hits[0]["doc_id"] in row["gold_docs"])
    return correct / len(eligible)


if __name__ == "__main__":
    main()
