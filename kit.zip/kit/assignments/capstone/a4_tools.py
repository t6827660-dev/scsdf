"""Capstone R2 - typed, safe tools."""
from __future__ import annotations
import re
from typing import Optional

from pydantic import BaseModel

from harness.backends import load_fee_schedule
from harness.types import ToolError


class AccountStatus(BaseModel):
    account_id: str
    product: str
    status: str
    masked_account_number: str
    freeze_reason: Optional[str] = None


class FeeQuote(BaseModel):
    fee_type: str
    unit_fee: float
    quantity: int
    free_quantity: int
    total: float
    schedule_id: str


class Ticket(BaseModel):
    ticket_id: str
    account_id: str
    reason: str
    priority: str
    created_new: bool


_ACCOUNT_RE = re.compile(r"^ACC-\d{4}$")


def _normalise_fee_type(value: str) -> str:
    raw = (value or "").strip().lower().replace("-", "_").replace(" ", "_")
    alias = {
        "domesticwire": "domestic_wire",
        "internationalwire": "international_wire",
        "incomingwire": "incoming_wire",
        "wirerecall": "wire_recall",
        "stoppayment": "stop_payment",
        "paperstatement": "paper_statement",
        "cardreplacement": "card_replacement",
        "excesswithdrawal": "excess_withdrawal",
    }
    return alias.get(raw, raw)


def lookup_account_status(db, account_id: str) -> AccountStatus:
    if not isinstance(account_id, str) or not _ACCOUNT_RE.match(account_id):
        raise ToolError("invalid_account_id", "account_id must match ACC-dddd")
    rec = db.get(account_id)
    if rec is None:
        raise ToolError("account_not_found", f"account {account_id} not found")
    number = str(rec.get("account_number", "")).strip()
    masked = "************" + (number[-4:] if len(number) >= 4 else number)
    return AccountStatus(
        account_id=account_id,
        product=str(rec.get("product", "")),
        status=str(rec.get("status", "")),
        masked_account_number=masked,
        freeze_reason=rec.get("freeze_reason"),
    )


def calculate_fee(fee_type: str, quantity: int = 1, plan: Optional[str] = None) -> FeeQuote:
    schedule = load_fee_schedule()
    fees = schedule.get("fees", {})
    mapped = _normalise_fee_type(str(fee_type or ""))
    if mapped not in fees:
        raise ToolError("unknown_fee_type", f"unknown fee_type: {fee_type}")
    if not isinstance(quantity, int) or quantity < 1 or quantity > 1000:
        raise ToolError("invalid_quantity", "quantity must be between 1 and 1000")
    allowed_plan = {None, "business_current", "premier_saver"}
    if plan not in allowed_plan:
        raise ToolError("unknown_plan", "plan must be None, business_current or premier_saver")
    unit_fee = float(fees[mapped])
    free_quantity = 0
    if mapped == "domestic_wire":
        allowance = schedule.get("free_allowance", {}).get("domestic_wire", {})
        if plan in allowance:
            free_quantity = int(allowance.get(plan, 0))
    total = 0.0 if quantity <= free_quantity else unit_fee * (quantity - free_quantity)
    return FeeQuote(
        fee_type=mapped,
        unit_fee=unit_fee,
        quantity=quantity,
        free_quantity=free_quantity,
        total=total,
        schedule_id=str(schedule.get("schedule_id", "")),
    )


def escalate_ticket(store, account_id: str, reason: str, priority: str) -> Ticket:
    if not isinstance(account_id, str) or not _ACCOUNT_RE.match(account_id):
        raise ToolError("invalid_account_id", "account_id must match ACC-dddd")
    norm_reason = " ".join((reason or "").strip().split())
    if not norm_reason or len(norm_reason) > 300:
        raise ToolError("invalid_reason", "reason must be non-empty and <= 300 chars")
    norm_priority = (priority or "").upper()
    if norm_priority not in {"P1", "P2", "P3"}:
        raise ToolError("invalid_priority", "priority must be P1, P2 or P3")
    for existing in getattr(store, "tickets", []):
        if existing.get("account_id") == account_id and existing.get("reason", "").strip().lower() == norm_reason.lower() and existing.get("priority") == norm_priority:
            return Ticket(
                ticket_id=existing["ticket_id"],
                account_id=account_id,
                reason=norm_reason,
                priority=norm_priority,
                created_new=False,
            )
    next_num = len(getattr(store, "tickets", [])) + 1
    ticket = {
        "ticket_id": f"TCK-{next_num:04d}",
        "account_id": account_id,
        "reason": norm_reason,
        "priority": norm_priority,
    }
    store.add(ticket)
    return Ticket(**{**ticket, "created_new": True})


def search_policy(retriever, query: str, k: int = 4) -> list:
    hits = retriever(query, k=k) if retriever is not None else []
    out = []
    for hit in hits:
        if not isinstance(hit, dict):
            continue
        out.append({
            "doc_id": hit.get("doc_id"),
            "chunk_id": hit.get("chunk_id"),
            "text": hit.get("text", ""),
        })
    return out
