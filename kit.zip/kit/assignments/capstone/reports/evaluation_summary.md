# Evaluation summary

The same 22 learner-authored questions were evaluated using hybrid retrieval with reranking disabled (baseline) and enabled (after). There are 19 answerable questions and three explicitly unanswerable questions. `faithfulness` is reported for answerable questions only; unanswerable cases are scored separately as `abstention_accuracy`. All measurements are local, deterministic, lexical/hash-based proxies, not a production guarantee.

| Metric | Baseline | After reranking | Change |
|---|---:|---:|---:|
| Context precision@5 | 0.853 | 0.892 | +0.039 |
| Context recall@5 | 0.982 | 0.974 | -0.009 |
| Retrieval top-1 accuracy | 0.895 | 0.947 | +0.053 |
| Faithfulness on answerable questions | 0.947 | 1.000 | +0.053 |
| Abstention accuracy | 0.955 | 1.000 | +0.045 |
| Answer relevance (hashing cosine) | 0.269 | 0.264 | -0.006 |
| p95 evaluation latency | 14.24 ms | 14.12 ms | -0.12 ms |
| Simulated cost | $0.0110 | $0.0118 | +$0.0008 |

Reranking improves top-1 correctness and precision on this set while slightly reducing recall, increasing simulated work, and slightly lowering the noisy answer-relevance proxy. The measured before/after supports the narrow claim that lexical coverage reranking improves first-result selection here; it does not establish universal quality gains. Remaining priorities are expanding paraphrase/unsupported-question coverage, retaining the small recall regression under review, and testing with human-judged relevance before any broader claim.

Machine-readable per-sample metrics are in [`eval_baseline.json`](./eval_baseline.json), [`eval_after.json`](./eval_after.json), and [`retrieval_comparison.json`](./retrieval_comparison.json). Regenerate them with `python assignments\capstone\run_eval.py` from the kit root.
