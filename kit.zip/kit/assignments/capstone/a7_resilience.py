"""Capstone R6 - resilience patterns. No real sleeping in tests: `sleep` and `clock` are injected.

CircuitBreaker(...)
call_with_resilience(...)
"""
from __future__ import annotations
import time


class CircuitBreaker:
    def __init__(self, failure_threshold=3, reset_after_s=30.0, clock=time.monotonic):
        self.failure_threshold = failure_threshold
        self.reset_after_s = reset_after_s
        self.clock = clock
        self.state = "closed"
        self._failure_count = 0
        self._opened_at = None

    def allow(self):
        now = self.clock()
        if self.state == "open":
            if self._opened_at is None:
                return False
            if now - self._opened_at >= self.reset_after_s:
                self.state = "half_open"
                return True
            return False
        if self.state == "half_open":
            return True
        return True

    def record_success(self):
        self._failure_count = 0
        self._opened_at = None
        self.state = "closed"

    def record_failure(self):
        now = self.clock()
        if self.state == "half_open":
            self.state = "open"
            self._opened_at = now
            self._failure_count = 0
            return
        self._failure_count += 1
        if self._failure_count >= self.failure_threshold:
            self.state = "open"
            self._opened_at = now


def call_with_resilience(fn, *, retries=3, base_delay=0.1, max_delay=2.0, timeout_budget_s=5.0, fallback=None, breaker=None,
                         sleep=time.sleep, clock=time.monotonic, retry_on=(Exception,)):
    start = clock()
    attempts = 0
    used_fallback = False
    value = None
    err = None

    for attempt in range(1, retries + 2):
        if breaker is not None and not breaker.allow():
            attempts = 0
            err = {"type": "CircuitOpen", "message": "circuit open"}
            if fallback is not None:
                try:
                    value = fallback()
                    used_fallback = True
                    return {"ok": True, "value": value, "attempts": 0, "error": err, "used_fallback": True, "elapsed_s": clock() - start}
                except Exception as e:
                    value = None
                    err = {"type": type(e).__name__, "message": str(e)}
                    return {"ok": False, "value": None, "attempts": 0, "error": err, "used_fallback": False, "elapsed_s": clock() - start}
            return {"ok": False, "value": None, "attempts": 0, "error": err, "used_fallback": False, "elapsed_s": clock() - start}

        try:
            attempts += 1
            value = fn()
            if breaker is not None:
                breaker.record_success()
            return {"ok": True, "value": value, "attempts": attempts, "error": None, "used_fallback": False, "elapsed_s": clock() - start}
        except Exception as exc:
            if breaker is not None:
                breaker.record_failure()
            err = {"type": type(exc).__name__, "message": str(exc)}
            if not isinstance(exc, retry_on):
                if fallback is not None:
                    try:
                        value = fallback()
                        used_fallback = True
                        return {"ok": True, "value": value, "attempts": attempts, "error": err, "used_fallback": True, "elapsed_s": clock() - start}
                    except Exception as e:
                        err = {"type": type(e).__name__, "message": str(e)}
                        return {"ok": False, "value": None, "attempts": attempts, "error": err, "used_fallback": False, "elapsed_s": clock() - start}
                return {"ok": False, "value": None, "attempts": attempts, "error": err, "used_fallback": False, "elapsed_s": clock() - start}

            if attempt >= retries + 1:
                if fallback is not None:
                    try:
                        value = fallback()
                        used_fallback = True
                        return {"ok": True, "value": value, "attempts": attempts, "error": err, "used_fallback": True, "elapsed_s": clock() - start}
                    except Exception as e:
                        err = {"type": type(e).__name__, "message": str(e)}
                        return {"ok": False, "value": None, "attempts": attempts, "error": err, "used_fallback": False, "elapsed_s": clock() - start}
                return {"ok": False, "value": None, "attempts": attempts, "error": err, "used_fallback": False, "elapsed_s": clock() - start}

            elapsed = clock() - start
            delay = min(base_delay * (2 ** (attempt - 1)), max_delay)
            if elapsed + delay > timeout_budget_s:
                err = {"type": "TimeoutBudgetExceeded", "message": f"timeout budget expired after {elapsed:.3f}s"}
                if fallback is not None:
                    try:
                        value = fallback()
                        used_fallback = True
                        return {"ok": True, "value": value, "attempts": attempts, "error": err, "used_fallback": True, "elapsed_s": elapsed}
                    except Exception as e:
                        err = {"type": type(e).__name__, "message": str(e)}
                        return {"ok": False, "value": None, "attempts": attempts, "error": err, "used_fallback": False, "elapsed_s": elapsed}
                return {"ok": False, "value": None, "attempts": attempts, "error": err, "used_fallback": False, "elapsed_s": elapsed}
            sleep(delay)

    return {"ok": False, "value": None, "attempts": attempts, "error": err, "used_fallback": False, "elapsed_s": clock() - start}
