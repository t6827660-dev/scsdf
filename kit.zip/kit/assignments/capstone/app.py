"""Capstone - Meridian Support Assistant."""
from __future__ import annotations
import copy, logging, pathlib, sys

HERE = pathlib.Path(__file__).resolve().parent
for _p in (HERE, HERE.parents[1]):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from a4_agent import handle as agent_handle
from a6_evals import Tracer
from a7_audit import AuditLog
from a7_guard import redact_pii
from a7_resilience import call_with_resilience
from harness.deps import make_deps
from harness.faults import is_active
from harness.types import AgentResult


logger = logging.getLogger(__name__)


class _ObservedLLM:
    def __init__(self, llm):
        self._llm = llm
        self.tokens_in = 0
        self.tokens_out = 0

    def __getattr__(self, name):
        return getattr(self._llm, name)

    def chat(self, messages, tools=None):
        response = self._llm.chat(messages, tools)
        usage = (response or {}).get("usage") or {}
        self.tokens_in += int(usage.get("tokens_in", 0))
        self.tokens_out += int(usage.get("tokens_out", 0))
        return response


class CapstoneApp:
    def __init__(self, deps=None, audit_path=None, trace_path=None):
        self.deps = deps or make_deps()
        self.audit_path = audit_path or (HERE / "audit" / "audit.jsonl")
        self.trace_path = trace_path or (HERE / "traces" / "app_trace.jsonl")
        self.audit = AuditLog(self.audit_path)
        self.trace_path = pathlib.Path(self.trace_path)
        self.trace_path.parent.mkdir(parents=True, exist_ok=True)

    def handle(self, request: str, role: str = "support_agent"):
        tracer = Tracer()
        try:
            with tracer.span("request", user=role, input=str(request or "")[:200]):
                result = self._process_request(request, role, tracer)
            tracer.to_jsonl(self.trace_path)
            return result
        except Exception as exc:  # pragma: no cover
            logger.error("Request processing failed (%s)", type(exc).__name__)
            degraded = AgentResult(intent="unknown", answer="degraded: service unavailable; a human has taken over.", tools_used=[], sources=[], needs_human=True, confidence=0.0)
            try:
                self.audit.append(tracer.trace_id, role, "unknown", {"request": redact_pii(request), "error_type": type(exc).__name__}, [], "failed")
            except Exception as audit_error:
                logger.error("Could not append failure to audit log (%s)", type(audit_error).__name__)
            try:
                tracer.to_jsonl(self.trace_path)
            except Exception as trace_error:
                logger.error("Could not export request trace (%s)", type(trace_error).__name__)
            return degraded

    def _process_request(self, request, role, tracer):
        normalized_request = str(request or "").strip()
        with tracer.span("authorise", user=role, input=normalized_request[:200]):
            if not normalized_request:
                result = AgentResult(
                    intent="unknown",
                    answer="Please provide a request.",
                    tools_used=[],
                    sources=[],
                    needs_human=False,
                    confidence=0.0,
                )
            else:
                result = None

        observer = _ObservedLLM(self.deps.llm)
        request_deps = copy.copy(self.deps)
        request_deps.llm = observer
        with tracer.span("tool_execution", input=normalized_request[:200]) as tool_span:
            if normalized_request:
                def execute():
                    if is_active("tool_outage"):
                        raise ConnectionError("account and tool backends unavailable")
                    return agent_handle(normalized_request, request_deps, role=role)

                resilient = call_with_resilience(
                    execute,
                    retries=0,
                    fallback=lambda: AgentResult(
                        intent="unknown",
                        answer="degraded: the service is temporarily unavailable and a human has taken over.",
                        tools_used=[],
                        sources=[],
                        needs_human=True,
                        confidence=0.1,
                    ),
                )
                result = resilient["value"]
                if resilient["error"]:
                    tool_span.set("error", resilient["error"]["type"])
                if resilient["used_fallback"]:
                    tool_span.set("degraded", True)
            tool_span.set("tokens_in", observer.tokens_in)
            tool_span.set("tokens_out", observer.tokens_out)

        if result is None:
            result = AgentResult(
                intent="unknown",
                answer="I could not complete the request; a human should review it.",
                tools_used=[],
                sources=[],
                needs_human=True,
                confidence=0.0,
            )
        elif not isinstance(result, AgentResult):
            result = AgentResult.model_validate(result)
        result.answer = redact_pii(result.answer)
        if result.needs_human and "human" not in result.answer.lower():
            result.answer += " Human review required."

        called_tools = result.tools_used or ["none"]
        outcome = (
            "degraded" if result.answer.lower().startswith("degraded")
            else "denied" if "not permitted" in result.answer.lower()
            else "ok"
        )
        with tracer.span("audit_write", user=role, tool_names=called_tools, sources=result.sources or []):
            self.audit.append(
                tracer.trace_id,
                role,
                ",".join(called_tools),
                {"request": redact_pii(normalized_request)},
                result.sources or [],
                outcome,
            )
        return result


def build_app(deps=None, audit_path=None, trace_path=None):
    return CapstoneApp(deps=deps, audit_path=audit_path, trace_path=trace_path)


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--demo", action="store_true")
    args = p.parse_args()
    if not args.demo:
        raise SystemExit("use --demo to run the offline demo")
    app = build_app()
    demo_questions = [
        "What is the status of ACC-1001?",
        "How much is an international wire fee?",
        "Who must approve a $30,000 wire initiated at the Harbor Street branch?",
        "Please escalate: fraud suspected on ACC-1002",
    ]
    for q in demo_questions:
        result = app.handle(q, "support_agent")
        print(f"Q: {q}\nA: {result.answer}\n")
    print("demo complete")
    raise SystemExit(0)
