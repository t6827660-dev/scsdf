"""CI quality gate."""
import json, sys
from pathlib import Path


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print("usage: eval_gate.py report.json [--min metric=value ...] [--max metric=value ...]", file=sys.stderr)
        return 2
    report_path = argv[0]
    try:
        report = json.loads(Path(report_path).read_text(encoding="utf-8", errors="replace"))
    except Exception as exc:
        print(f"ERROR: cannot read {report_path}: {exc}", file=sys.stderr)
        return 2

    mins = []
    maxs = []
    i = 1
    while i < len(argv):
        if argv[i] not in {"--min", "--max"}:
            print(f"ERROR: unsupported argument {argv[i]}", file=sys.stderr)
            return 2
        kind = argv[i]
        i += 1
        if i >= len(argv):
            print(f"ERROR: missing value after {kind}", file=sys.stderr)
            return 2
        pair = argv[i]
        if "=" not in pair:
            print(f"ERROR: expected metric=value in {pair}", file=sys.stderr)
            return 2
        metric, value = pair.split("=", 1)
        try:
            num = float(value)
        except ValueError:
            print(f"ERROR: invalid number {value}", file=sys.stderr)
            return 2
        if kind == "--min":
            mins.append((metric, num))
        else:
            maxs.append((metric, num))
        i += 1

    def get_metric(name):
        if name in report.get("metrics", {}):
            return report["metrics"][name]
        if name == "latency_p50_ms":
            return report.get("latency_ms", {}).get("p50")
        if name == "latency_p95_ms":
            return report.get("latency_ms", {}).get("p95")
        if name == "sim_cost_usd":
            return report.get("sim_cost_usd")
        return None

    all_ok = True
    for metric, limit in mins + maxs:
        actual = get_metric(metric)
        if actual is None:
            print(f"FAIL {metric}: metric missing")
            all_ok = False
            continue
        if metric in {x[0] for x in mins}:
            ok = actual >= limit
            label = "PASS" if ok else "FAIL"
            print(f"{label} {metric}: {actual} >= {limit}")
            if not ok:
                all_ok = False
        else:
            ok = actual <= limit
            label = "PASS" if ok else "FAIL"
            print(f"{label} {metric}: {actual} <= {limit}")
            if not ok:
                all_ok = False
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
