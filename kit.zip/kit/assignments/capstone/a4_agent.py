"""Capstone R3 - the agent."""
from __future__ import annotations
import re

from a4_tools import calculate_fee, escalate_ticket, lookup_account_status, search_policy
from a7_guard import authorize, redact_pii, secure_answer
from harness.backends import load_fee_schedule
from harness.types import AgentResult


_ACC_RE = re.compile(r"ACC-\d{4}")


def _find_account(request):
    m = _ACC_RE.search(request)
    return m.group(0) if m else None


def _find_fee_type(request):
    q = request.lower()
    aliases = {
        "domestic_wire": ("domestic wire", "local wire"),
        "international_wire": ("international wire", "outgoing international", "overseas wire"),
        "incoming_wire": ("incoming wire", "wire received"),
        "wire_recall": ("wire recall", "recall a wire"),
        "stop_payment": ("stop payment", "stop-payment"),
        "overdraft": ("overdraft", "overdrawn"),
        "paper_statement": ("paper statement", "printed statement"),
        "card_replacement": ("card replacement", "replace a card", "replacement card"),
        "excess_withdrawal": ("excess withdrawal", "extra withdrawal"),
    }
    for fee_type in load_fee_schedule().get("fees", {}):
        for phrase in aliases.get(fee_type, (fee_type.replace("_", " "),)):
            if phrase in q:
                return fee_type
    return None


def _quantity(request):
    match = re.search(
        r"\b(\d{1,4})\s+(?:(?:outgoing|domestic|international|incoming)\s+)?"
        r"(?:wires?(?:\s+transfers?)?|statements?|cards?|withdrawals?|payments?|items?|requests?)\b",
        request,
        re.I,
    )
    if match:
        return int(match.group(1))
    words = {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    }
    word_match = re.search(
        r"\b(" + "|".join(words) + r")\s+(?:(?:outgoing|domestic|international|incoming)\s+)?"
        r"(?:wires?(?:\s+transfers?)?|statements?|cards?|withdrawals?|payments?|items?|requests?)\b",
        request,
        re.I,
    )
    return words[word_match.group(1).lower()] if word_match else 1


def _approval_answer(request, retriever):
    hits = search_policy(
        retriever,
        "payment approval matrix single-approver limits wire authority dual control",
        k=8,
    )
    matrix = "\n".join(h["text"] for h in hits if h.get("doc_id") == "RISK-001")
    amount_match = re.search(r"\$\s?([\d,]+(?:\.\d+)?)", request)
    if not matrix or not amount_match:
        return None

    amount = float(amount_match.group(1).replace(",", ""))
    limits = []
    for line in matrix.splitlines():
        match = re.search(r"[-*]\s*([^:]+):\s*up to\s*\$([\d,]+)", line, re.I)
        if match:
            limits.append((float(match.group(2).replace(",", "")), match.group(1).strip()))
        match = re.search(r"[-*]\s*([^:]+):\s*any amount above\s*\$([\d,]+)", line, re.I)
        if match and amount > float(match.group(2).replace(",", "")):
            limits.append((float("inf"), match.group(1).strip()))
    if not limits:
        return None
    authority = next(
        (role_name for limit, role_name in sorted(limits) if amount <= limit),
        limits[-1][1],
    )

    used_docs = ["RISK-001"]
    approver = None
    if authority.lower() in {"regional director", "branch manager", "head of payments"}:
        branch_match = re.search(
            r"\b(?:at|from|in|raised at)\s+(?:the\s+)?"
            r"([A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+){0,2})\s+branch\b",
            request,
        )
        org_query = authority
        if branch_match:
            org_query += " " + branch_match.group(1)
        org_hits = search_policy(retriever, org_query, k=8)
        org_text = "\n".join(h["text"] for h in org_hits if h.get("doc_id") == "ORG-001")
        if org_text:
            used_docs.append("ORG-001")
        if authority.lower() == "head of payments":
            head = re.search(
                r"([A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+)+)\s+is the Head of Payments\b",
                org_text,
                re.I,
            )
            if head:
                approver = head.group(1)
        if branch_match and authority.lower() != "head of payments":
            branch = branch_match.group(1)
            if authority.lower() == "branch manager":
                manager = re.search(
                    rf"([A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+)+)\s+is the Branch Manager of {re.escape(branch)}\b",
                    org_text,
                    re.I,
                )
                if manager:
                    approver = manager.group(1)
            else:
                directors = re.finditer(
                    r"([A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+)+)\s+is the Regional Director of ([^.]+)\.",
                    org_text,
                    re.I,
                )
                for director in directors:
                    region_text = org_text[director.end():]
                    next_director = re.search(
                        r"[A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+)+ is the Regional Director of",
                        region_text,
                        re.I,
                    )
                    if next_director:
                        region_text = region_text[:next_director.start()]
                    if re.search(rf"\b{re.escape(branch)}\b", region_text, re.I):
                        approver = director.group(1)
                        break

    name = f" ({approver})" if approver else ""
    dual = " Wires of $10,000 or more also require dual control." if amount >= 10000 else ""
    return f"A ${amount:,.0f} wire requires a {authority}{name} as the final approver.{dual}", used_docs


def handle(request: str, deps, role=None) -> AgentResult:
    q = request or ""
    role = role or getattr(deps, "user_role", "support_agent")
    try:
        account = _find_account(q)
        if account and any(k in q.lower() for k in ("status", "balance", "active", "frozen", "closed")):
            if not authorize(role, "lookup_account_status"):
                return AgentResult(intent="account_status", answer="Your role is not permitted to look up account status; a human must review this request.", tools_used=[], sources=[], needs_human=True, confidence=0.1)
            result = lookup_account_status(deps.db, account)
            tools_used = ["lookup_account_status"]
            if result.status.lower() in {"frozen", "closed"}:
                needs_human = True
                answer = f"The account {account} is {result.status} and needs a human review."
            else:
                needs_human = False
                answer = f"The account {account} is {result.status}."
            answer = redact_pii(answer)
            return AgentResult(intent="account_status", answer=answer, tools_used=tools_used, sources=[], needs_human=needs_human, confidence=0.9)

        fee_type = _find_fee_type(q)
        asks_policy = any(term in q.lower() for term in ("policy", "written rule", "guideline", "documentation", "source document"))
        asks_quote = any(term in q.lower() for term in ("quote", "calculate", "how much", "what is the fee", "what does it cost"))
        if fee_type and (
            any(k in q.lower() for k in ("fee", "cost", "charge", "price", "how much"))
            or "wire" in q.lower()
        ) and (not asks_policy or asks_quote):
            if not authorize(role, "calculate_fee"):
                return AgentResult(intent="fee_quote", answer="Your role is not permitted to calculate fees; a human must review this request.", tools_used=[], sources=[], needs_human=True, confidence=0.1)
            qty = _quantity(q)
            q_lower = q.lower()
            plan = "business_current" if "business current" in q_lower else "premier_saver" if "premier saver" in q_lower else None
            tools_used = ["calculate_fee"]
            if account and fee_type == "domestic_wire" and plan is None:
                if not authorize(role, "lookup_account_status"):
                    return AgentResult(intent="fee_quote", answer="Your role is not permitted to check account plan details; a human must review this request.", tools_used=[], sources=[], needs_human=True, confidence=0.1)
                account_status = lookup_account_status(deps.db, account)
                plan = {
                    "Business Current": "business_current",
                    "Premier Saver": "premier_saver",
                }.get(account_status.product)
                tools_used.insert(0, "lookup_account_status")
            quote = calculate_fee(fee_type, quantity=qty, plan=plan)
            answer = f"The {qty} {fee_type.replace('_', ' ')} fee{'s' if qty != 1 else ''} total ${quote.total:.2f}."
            if quote.total == 0:
                answer = f"The {fee_type.replace('_', ' ')} fee is waived for this account plan."
            return AgentResult(intent="fee_quote", answer=redact_pii(answer), tools_used=tools_used, sources=[], needs_human=False, confidence=0.85)

        if any(k in q.lower() for k in ("fraud", "escalate", "complain")):
            if not authorize(role, "escalate_ticket"):
                return AgentResult(intent="escalation", answer="Your role is not permitted to create an escalation; a human must review this request.", tools_used=[], sources=[], needs_human=True, confidence=0.1)
            if account is None:
                return AgentResult(intent="escalation", answer="I need the account ID before I can create an escalation. No ticket was created; please provide the account ID or contact a human agent.", tools_used=[], sources=[], needs_human=True, confidence=0.3)
            reason = q[:200]
            lower_q = q.lower()
            priority = "P1" if "fraud" in lower_q or "security breach" in lower_q else "P2" if any(term in lower_q for term in ("delayed", "failed", "missing transfer", "payment not received")) else "P3"
            ticket = escalate_ticket(deps.tickets, account, reason, priority)
            return AgentResult(intent="escalation", answer=f"Escalation ticket {ticket.ticket_id} created for {account}; a human will review it.", tools_used=["escalate_ticket"], sources=[], needs_human=True, confidence=0.9)

        if any(k in q.lower() for k in ("approve", "approval")) and not any(k in q.lower() for k in ("transfer", "send", "move")):
            if not authorize(role, "search_policy"):
                return AgentResult(intent="policy_question", answer="Your role is not permitted to search policy; a human must review this request.", tools_used=[], sources=[], needs_human=True, confidence=0.1)
            approval = _approval_answer(q, deps.retriever)
            if approval:
                answer, docs = approval
                answer += "\nSources: " + ", ".join(docs)
                return AgentResult(intent="policy_question", answer=answer, tools_used=["search_policy"], sources=docs, needs_human=False, confidence=0.9)

        if any(k in q.lower() for k in ("transfer", "send", "move")):
            if not authorize(role, "initiate_transfer"):
                return AgentResult(intent="transfer", answer="Your role is not permitted to initiate a transfer; a human must review this request.", tools_used=[], sources=[], needs_human=True, confidence=0.1)
            return AgentResult(intent="transfer", answer="I can help with a transfer request, but this needs a human approval step and a transfer tool flow.", tools_used=[], sources=[], needs_human=True, confidence=0.4)

        if q.strip():
            if not authorize(role, "search_policy"):
                return AgentResult(intent="policy_question", answer="Your role is not permitted to search policy; a human must review this request.", tools_used=[], sources=[], needs_human=True, confidence=0.1)
            safe = secure_answer(q, deps)
            hits = search_policy(deps.retriever, q, k=5)
            docs = list(dict.fromkeys(h.get("doc_id") for h in hits if h.get("doc_id")))
            answer = redact_pii(safe["answer"])
            if not docs or answer.startswith("I could not find"):
                docs = []
                answer = "I could not find a supported answer in the policy corpus."
            return AgentResult(intent="policy_question", answer=answer, tools_used=["search_policy"], sources=docs, needs_human=False, confidence=0.75 if docs else 0.35)

        answer = "I could not complete that request. Please provide a valid account ID or policy question."
        return AgentResult(intent="unknown", answer=answer, tools_used=[], sources=[], needs_human=False, confidence=0.2)
    except Exception as exc:  # pragma: no cover
        msg = redact_pii(str(exc))
        return AgentResult(intent="unknown", answer=f"I could not complete the request: {msg}", tools_used=[], sources=[], needs_human=False, confidence=0.1)
