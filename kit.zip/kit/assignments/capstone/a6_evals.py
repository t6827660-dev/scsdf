"""Capstone R4 - tracing + evaluation."""
from __future__ import annotations
import json, math, re, uuid
from contextlib import contextmanager
from pathlib import Path
import time

from harness.text import HashingEmbedder, cosine, tokenize


def _nearest_rank(values, pct):
    if not values:
        return 0.0
    if len(values) == 1:
        return float(values[0])
    rank = max(1, math.ceil((pct / 100.0) * len(values)))
    return float(sorted(values)[rank - 1])


def context_precision(retrieved, gold):
    if not retrieved or not gold:
        return 0.0
    relevant = set(gold)
    precisions = []
    seen = 0
    for i, item in enumerate(retrieved, 1):
        if item in relevant:
            seen += 1
            precisions.append(seen / i)
    if not precisions:
        return 0.0
    return sum(precisions) / len(precisions)


def context_recall(retrieved, gold):
    if not gold:
        return 0.0
    return len(set(retrieved) & set(gold)) / len(set(gold))


def faithfulness(answer, contexts, threshold=0.6):
    if not answer or not contexts:
        if not answer:
            return 0.0
        contexts = []
    try:
        context_tokens = set(tokenize(" ".join(str(c) for c in contexts)))
    except Exception:
        context_tokens = set()
    sentences = re.split(r'(?<=[.!?])\s+|\n+', str(answer).strip())
    counted = 0
    supported = 0
    for sentence in sentences:
        toks = tokenize(sentence)
        if not toks:
            continue
        counted += 1
        overlap = sum(1 for tok in toks if tok in context_tokens)
        if len(toks) and overlap / len(toks) >= threshold:
            supported += 1
    if counted == 0:
        return 0.0
    return supported / counted


def answer_relevance(question, answer):
    if not answer:
        return 0.0
    embedder = HashingEmbedder()
    q = embedder.embed(str(question))
    a = embedder.embed(str(answer))
    return cosine(q, a)


def tool_call_accuracy(expected, actual):
    if not expected and not actual:
        return 1.0
    cursor = 0
    matched = 0
    for exp in expected:
        for idx in range(cursor, len(actual)):
            act = actual[idx]
            if act.get("name") != exp.get("name"):
                continue
            if all(act.get("args", {}).get(k) == v for k, v in (exp.get("args", {}) or {}).items()):
                matched += 1
                cursor = idx + 1
                break
    return matched / max(len(expected), len(actual))


def run_eval(system_fn, dataset, clock=time.perf_counter, usd_per_1k_tokens=0.002):
    latencies = []
    metric_values = {}
    total_in = 0
    total_out = 0
    per_sample = []
    for row in dataset:
        start = clock()
        result = system_fn(row["question"])
        elapsed_ms = (clock() - start) * 1000.0
        latencies.append(elapsed_ms)
        total_in += int(result.get("tokens_in", 0))
        total_out += int(result.get("tokens_out", 0))
        sample = {"id": row.get("id"), "latency_ms": elapsed_ms, "metrics": {}}
        gold = row.get("gold_docs", [])
        if gold:
            sample["metrics"]["context_precision"] = context_precision(result.get("retrieved_ids", []), gold)
            sample["metrics"]["context_recall"] = context_recall(result.get("retrieved_ids", []), gold)
            sample["metrics"]["faithfulness"] = faithfulness(result.get("answer", ""), result.get("contexts", []))
        sample["metrics"]["abstention_accuracy"] = float(
            bool(result.get("abstained", False)) == (not bool(gold))
        )
        sample["metrics"]["answer_relevance"] = answer_relevance(row.get("question", ""), result.get("answer", ""))
        expected = row.get("expected_tool_calls")
        if expected is not None:
            sample["metrics"]["tool_call_accuracy"] = tool_call_accuracy(expected, result.get("tool_calls", []))
        per_sample.append(sample)
        for name, val in sample["metrics"].items():
            metric_values.setdefault(name, []).append(val)
    metrics = {name: (sum(vals) / len(vals)) for name, vals in metric_values.items()}
    out = {
        "n": len(dataset),
        "metrics": metrics,
        "latency_ms": {"p50": _nearest_rank(latencies, 50), "p95": _nearest_rank(latencies, 95)},
        "tokens": {"in": total_in, "out": total_out},
        "sim_cost_usd": ((total_in + total_out) / 1000.0) * usd_per_1k_tokens,
        "per_sample": per_sample,
    }
    return out


class _Span(dict):
    def __init__(self, trace_id, span_id, parent_id, name, start_ms, attrs):
        super().__init__(trace_id=trace_id, span_id=span_id, parent_id=parent_id, name=name, start_ms=start_ms, end_ms=None, attrs=dict(attrs))

    def set(self, key, value):
        self["attrs"][key] = value


class Tracer:
    def __init__(self, clock=time.perf_counter):
        self.clock = clock
        self.trace_id = uuid.uuid4().hex
        self.start_ms = self.clock()
        self.spans = []
        self._stack = []

    @contextmanager
    def span(self, name, **attrs):
        parent_id = self._stack[-1]["span_id"] if self._stack else None
        span = _Span(self.trace_id, uuid.uuid4().hex, parent_id, name, (self.clock() - self.start_ms) * 1000.0, attrs)
        self.spans.append(span)
        self._stack.append(span)
        try:
            yield span
        except Exception as exc:
            span["attrs"]["error"] = type(exc).__name__
            raise
        finally:
            span["end_ms"] = (self.clock() - self.start_ms) * 1000.0
            if self._stack and self._stack[-1] is span:
                self._stack.pop()

    def to_jsonl(self, path):
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("a", encoding="utf-8") as fh:
            for row in self.spans:
                fh.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")


def analyze_trace(path_or_spans):
    if isinstance(path_or_spans, (str, Path)):
        path = Path(path_or_spans)
        spans = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.strip():
                spans.append(json.loads(line))
    else:
        spans = list(path_or_spans)
    if not spans:
        return {"total_ms": 0.0, "slowest_span": None, "slowest_ms": 0.0, "duplicate_calls": [], "total_tokens": 0, "span_count": 0}
    root = next((s for s in spans if s.get("parent_id") is None), spans[0])
    non_root = [s for s in spans if s is not root]
    slow = max(non_root, key=lambda s: (s.get("end_ms", 0) - s.get("start_ms", 0)), default=root)
    slow_ms = (slow.get("end_ms", 0) - slow.get("start_ms", 0)) if slow is not root else 0.0
    dup_counts = {}
    for s in non_root:
        if s.get("attrs", {}).get("input") is not None:
            dup_counts[(s.get("name"), s.get("attrs", {}).get("input"))] = dup_counts.get((s.get("name"), s.get("attrs", {}).get("input")), 0) + 1
    duplicate_calls = [{"name": name, "count": count} for (name, _), count in sorted(dup_counts.items(), key=lambda x: (-x[1], x[0][0])) if count > 1]
    total_tokens = sum(int(s.get("attrs", {}).get("tokens_in", 0)) + int(s.get("attrs", {}).get("tokens_out", 0)) for s in spans)
    return {
        "total_ms": float(root.get("end_ms", 0) - root.get("start_ms", 0)),
        "slowest_span": slow.get("name") if slow is not root else None,
        "slowest_ms": slow_ms,
        "duplicate_calls": duplicate_calls,
        "total_tokens": total_tokens,
        "span_count": len(spans),
    }
