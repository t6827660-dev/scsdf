"""Run an offline probe of all supported fault injections."""
from __future__ import annotations
import json
import math
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
CAPSTONE = HERE.parent
KIT_ROOT = CAPSTONE.parents[1]
for path in (KIT_ROOT, CAPSTONE):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from app import build_app
from harness.deps import make_deps
from harness.faults import FAULTS, inject


def percentile95(values):
    if not values:
        return 0.0
    return float(sorted(values)[max(0, math.ceil(0.95 * len(values)) - 1)])


def read_jsonl(path):
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main():
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    trace_dir = CAPSTONE / "traces"
    audit_dir = CAPSTONE / "audit"
    trace_dir.mkdir(exist_ok=True)
    audit_dir.mkdir(exist_ok=True)
    question = "What are the opening hours for Meridian branches?"
    requests = (
        "What is the status of ACC-1001?",
        question,
    )
    expected_doc = "FAQ-001"
    results = {}

    for fault in FAULTS:
        trace_path = trace_dir / f"gameday_{run_id}_{fault}.jsonl"
        audit_path = audit_dir / f"gameday_{run_id}_{fault}.jsonl"
        deps = make_deps()
        app = build_app(deps=deps, audit_path=audit_path, trace_path=trace_path)
        latencies_ms = []
        tokens_per_request = []
        top1_matches = []
        degraded_count = 0
        retrieval_errors = 0

        for _ in range(5):
            with inject(fault):
                try:
                    hits = deps.retriever(question, k=5)
                    top1_matches.append(bool(hits and hits[0].get("doc_id") == expected_doc))
                except ConnectionError:
                    retrieval_errors += 1
                for request in requests:
                    result = app.handle(request, "support_agent")
                    degraded_count += bool(result.needs_human or result.answer.lower().startswith("degraded"))
                    spans = [
                        span for span in read_jsonl(trace_path)
                        if span.get("trace_id") == _latest_trace_id(trace_path)
                    ]
                    root = next((span for span in spans if span.get("parent_id") is None), None)
                    if root:
                        latencies_ms.append(root["end_ms"] - root["start_ms"])
                        tokens_per_request.append(
                            sum(
                                int(span.get("attrs", {}).get("tokens_in", 0))
                                + int(span.get("attrs", {}).get("tokens_out", 0))
                                for span in spans
                            )
                        )

        results[fault] = {
            "requests": len(latencies_ms),
            "latency_p95_ms": round(percentile95(latencies_ms), 2),
            "tokens_per_request_mean": round(sum(tokens_per_request) / max(1, len(tokens_per_request)), 2),
            "expected_doc_ranked_first_rate": (
                round(sum(top1_matches) / len(top1_matches), 3) if top1_matches else None
            ),
            "retrieval_errors": retrieval_errors,
            "degraded_requests": degraded_count,
            "slowest_span": _slowest_span(trace_path),
            "trace_file": str(trace_path.relative_to(KIT_ROOT)),
            "audit_verifies": _audit_verifies(audit_path),
        }

    report = {
        "measured_at_utc": datetime.now(timezone.utc).isoformat(),
        "environment": "local synthetic harness; five requests per fault; no external services",
        "question": question,
        "expected_doc": expected_doc,
        "faults": results,
    }
    out = HERE / "gameday_results.json"
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


def _latest_trace_id(path):
    spans = read_jsonl(path)
    if not spans:
        return None
    return spans[-1].get("trace_id")


def _slowest_span(path):
    spans = read_jsonl(path)
    spans = [span for span in spans if span.get("parent_id") is not None]
    if not spans:
        return None
    span = max(spans, key=lambda item: item.get("end_ms", 0) - item.get("start_ms", 0))
    return {
        "name": span.get("name"),
        "duration_ms": round(span.get("end_ms", 0) - span.get("start_ms", 0), 2),
    }


def _audit_verifies(path):
    from a7_audit import AuditLog
    return AuditLog(path).verify().get("ok", False)


if __name__ == "__main__":
    main()
