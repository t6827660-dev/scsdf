# Game-day report

## Setup and method

Measured locally on 2026-10-24 using the synthetic harness, five repetitions of two requests per fault (one account status request and one branch-hours policy request), with no external services. The probe also queried the harness retriever directly five times per fault for `FAQ-001`; this separate retrieval check explains why the outage case can still rank a document while the application's request path is degraded. Latencies and token use are local measurements, not production SLOs.

The p95 is computed across ten app requests per fault. Tokens/request is the mean across app requests and is collected from request trace spans. The slowest span excludes the root request span. Every generated audit file verified successfully.

| Fault | Requests | p95 latency (ms) | Mean tokens/request | `FAQ-001` top-1 rate | Degraded requests | Slowest span (ms) | Audit |
|---|---:|---:|---:|---:|---:|---|---|
| `tool_outage` | 10 | 10.27 | 0 | 1.00 | 10/10 | `audit_write` (10.08) | PASS |
| `bad_retrieval` | 10 | 15.59 | 189.5 | 0.00 | 0/10 | `audit_write` (8.91) | PASS |
| `cost_spike` | 10 | 5.38 | 1,516 | 1.00 | 0/10 | `tool_execution` (3.79) | PASS |
| `slow_tool` | 10 | 253.11 | 189.5 | 1.00 | 0/10 | `tool_execution` (250.85) | PASS |

## Findings and response

- **Tool outage:** all application requests used the visible human hand-off; the app made no successful tool claim and recorded zero LLM tokens. The isolated retriever ranking probe still returned the expected FAQ, since this injected fault affects the request/tool boundary rather than the local retriever.
- **Bad retrieval:** the retriever's reversal changed the expected FAQ top-1 rate from the normal ordering to 0.00 in the probe. Requests still completed; this demonstrates why retrieval quality needs a distinct signal instead of relying only on availability or latency.
- **Cost spike:** the injected multiplier increased mean request tokens to 1,516, roughly eight times the 189.5-token mean seen for the policy-query requests without the multiplier. Token usage is visible in the trace; a production budget/rate limiter is not implemented.
- **Slow tool:** p95 was about 253 ms and the longest non-root `tool_execution` span was about 251 ms, consistent with the harness's injected 250 ms delay. The app completed normally; there is no real production timeout or alerting integration.

## Reproduction and evidence

From the kit root, run `python assignments\capstone\gameday\run_probe.py`. It writes timestamped JSONL traces and audit files under `assignments\capstone\traces` and `assignments\capstone\audit`, plus structured measurements in [`gameday_results.json`](./gameday_results.json). The run measured above is recorded in that JSON file. To reproduce with fresh numbers, rerun the probe; local timing may vary.

The synthetic results cannot estimate real dependency availability, queue depth, customer impact, or recovery time. There is no alerting channel or production dashboard. Production use would require service-level telemetry, an on-call owner, and a tested operator escalation path.
