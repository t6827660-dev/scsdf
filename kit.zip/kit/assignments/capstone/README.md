# Meridian Support Assistant

This capstone is an offline prototype for Meridian Bank support and policy questions. It answers account-status and fee questions with narrow deterministic tools, searches the synthetic policy corpus for policy questions, and creates an idempotent escalation ticket for fraud or complaint requests. It is deliberately not a payment execution system: transfers are not posted, sensitive decisions are handed to a person, and no answer should be treated as legal, financial, or operational approval.

All examples use fictional data. The runtime uses the local harness and a rule-based model; it makes no network calls and requires no model key. Retrieved documents are untrusted data. The guard removes instruction-like sentences before retrieval output reaches the model, records documents that contained such text, and redacts common PII patterns from answers and audit arguments.

## Run it

From the kit root, install dependencies with `python -m pip install -r requirements.txt`. Then run:

```powershell
Set-Location assignments\capstone
python app.py --demo
$env:GAMEDAY_FAULT = "tool_outage"
python app.py --demo
Remove-Item Env:GAMEDAY_FAULT
Set-Location ..\..
python -m autograde.run --capstone --root . -v
python -m pytest assignments\capstone\tests
```

The grader's component and integration checks are the main automated validation. `python run_eval.py` evaluates the same original 22-question synthetic set using hybrid retrieval before and after lexical coverage reranking, then saves comparable reports under `reports/`. `python gameday\run_probe.py` exercises all four harness faults and records measured results and per-run JSONL traces. `eval_gate.py` applies numeric thresholds, and `.github\workflows\eval.yml` runs the evaluation and gate in CI.

## Layout

- `app.py` wires authorization, tools, request handling, tracing, audit, and graceful outage behavior.
- `a2_rag.py` chunks the synthetic corpus and implements BM25, dense-hash, and hybrid retrieval.
- `a4_tools.py` validates account, fee, ticket, and policy-search operations.
- `a4_agent.py` routes common requests to those tools and returns a typed `AgentResult`.
- `a7_guard.py`, `a7_audit.py`, and `a7_resilience.py` implement safety, audit, and retry/breaker primitives.
- `a6_evals.py` implements deterministic metrics and JSONL tracing.
- `docs/` contains architecture, operating, business, governance, and decision notes. `reports/` contains measured evaluations; `traces/` and `audit/` contain local run evidence.

## Design choices and evaluation

Section chunking preserves document headings and is the default for short policy documents. Fixed windows and sentence-grouped semantic chunks are available for comparison. Hybrid retrieval fuses BM25 and deterministic hashing-embedding ranks; the public grader measured recall@5 of 0.77 for BM25, 0.93 for dense, and 0.75 for hybrid on its visible and hold-out set. Superseded documents remain indexed only when explicitly requested, while normal retrieval filters them. A stale fee schedule must never outrank the current 2025 schedule. Fee tool requests parse count quantities separately from monetary amounts, and domestic-wire allowances can be computed from an explicitly stated plan or a narrow account lookup. Approval roles and branch approvers are derived from retrieved policy passages rather than hardcoded to one branch or amount.

Metrics describe a small, learner-authored synthetic dataset, not a production guarantee. Recall and precision measure document ranking, faithfulness is lexical token overlap, and answer relevance is a hashing-vector cosine. These metrics cannot prove factual correctness, policy completeness, fairness, or safe operation under real workloads. Inspect individual traces and documents as well as aggregate values. See `docs/architecture.md` for data flow, `docs/runbook.md` for operations, and `docs/threat_model.md` for threats and residual risks.
