# Meridian Support Assistant demo

**Recording:** Not recorded; this script is intended for the live capstone defence.

## Script (under seven minutes)

1. Run `python app.py --demo` and show a status lookup, current fee quote, policy answer, and idempotent fraud escalation.
2. Ask a branch-hours question that retrieves FAQ-001. Explain that instruction-like text is removed as untrusted content while the opening-hours evidence and document citation remain.
3. Run with `GAMEDAY_FAULT=tool_outage` and show the explicit degraded human hand-off; clear the fault and demonstrate recovery.
4. Open `traces/app_trace.jsonl` and `audit/audit.jsonl`. Verify that each request has trace spans and that the audit hash chain validates.
5. Compare `reports/eval_baseline.json` and `reports/eval_after.json` on the same evaluation dataset. Explain that ranking and lexical overlap metrics do not prove factual safety.
6. State the weakest business-case assumption: that the assistant reduces lookup time without adding verification burden. No real payment execution or real customer data is in scope.
